# CID10 - SQL

CID10 - É A Classificação Estatística Internacional de Doenças e Problemas Relacionados com a Saúde, frequentemente designada pela sigla CID (em inglês: International Statistical Classification of Diseases and Related Health Problems - ICD) fornece códigos relativos à classificação de doenças e de uma grande variedade de sinais, sintomas, aspectos anormais, queixas, circunstâncias sociais e causas externas para ferimentos ou doenças.

O intuito do projeto é disponibilizar SQLs para facilitar a inserção de valores referente à CID10 em um banco de dados relacional
